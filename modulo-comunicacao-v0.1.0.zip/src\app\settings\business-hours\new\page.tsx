'use client'

import { BusinessHoursForm } from '../components/business-hours-form'

export default function NewBusinessHoursPage() {
  return (
    <div className="container py-6">
      <BusinessHoursForm />
    </div>
  )
} 