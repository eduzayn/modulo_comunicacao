'use client'

import { TagForm } from '../components/tag-form'

export default function NewTagPage() {
  return <TagForm />
} 