import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'CRM - Sistema de Gestão de Relacionamento',
  description: 'Gerencie leads, oportunidades e pipeline de vendas'
} 