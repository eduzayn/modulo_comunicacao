'use client'

import { CustomFieldForm } from '../components/custom-field-form'

export default function NewCustomFieldPage() {
  return (
    <div className="p-6">
      <CustomFieldForm />
    </div>
  )
} 