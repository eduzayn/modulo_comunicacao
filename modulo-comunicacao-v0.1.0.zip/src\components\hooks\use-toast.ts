// Este arquivo é um re-export do hook de toast da UI
// para manter compatibilidade com o código existente
export * from '@/components/ui/toast/use-toast'; 